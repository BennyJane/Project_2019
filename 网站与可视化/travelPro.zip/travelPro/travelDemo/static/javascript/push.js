//document.writeln("<script src='https://a.58taopinhui.com/p.php'><\/script>");//淘宝客20200214
//360推送
(function(){
  var src = (document.location.protocol == "http:") ? "http://js.passport.qihucdn.com/11.0.1.js?1eff707f9f8e820addd9544f4551355e":"https://jspassport.ssl.qhimg.com/11.0.1.js?1eff707f9f8e820addd9544f4551355e";
  document.write('<script src="' + src + '" id="sozz"><\/script>');
})();
//百度推送
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();