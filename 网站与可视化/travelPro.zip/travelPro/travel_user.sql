INSERT INTO travel.user (id, username, password, update_time) VALUES (1, 'admin', '123456', '2020-06-08 23:21:25');
INSERT INTO travel.user (id, username, password, update_time) VALUES (2, 'benny03', '123456', '2020-06-08 23:07:45');
INSERT INTO travel.user (id, username, password, update_time) VALUES (3, 'jack02', '123456', '2020-06-08 23:07:45');